package com.hotspotproxy

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager

class ProxyService : Service() {

    companion object {
        @Volatile var running = false
        @Volatile var lastError: String? = null
    }

    private var server: ProxyServer? = null
    private var wl: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "stop") {
            stopSelf()
            return START_NOT_STICKY
        }
        if (server != null) return START_NOT_STICKY

        val p = getSharedPreferences("cfg", MODE_PRIVATE)
        val port = p.getInt("port", 8080)
        val user = p.getString("user", "") ?: ""
        val pass = p.getString("pass", "") ?: ""

        val n = buildNotification(port)
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }

        wl = (getSystemService(POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "hotspotproxy:wl")
            .apply { acquire() }

        lastError = null
        Thread {
            try {
                val s = ProxyServer(port, user, pass)
                s.start()
                server = s
                running = true
            } catch (e: Exception) {
                lastError = e.message ?: e.toString()
                running = false
                stopSelf()
            }
        }.start()
        return START_NOT_STICKY
    }

    private fun buildNotification(port: Int): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("proxy", "الوكيل", NotificationManager.IMPORTANCE_LOW)
        )
        val stopPi = PendingIntent.getService(
            this, 0, Intent(this, ProxyService::class.java).setAction("stop"),
            PendingIntent.FLAG_IMMUTABLE
        )
        val openPi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, "proxy")
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("Music")
            .setContentText("قيد التشغيل")
            .setContentIntent(openPi)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "إيقاف", stopPi)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        server?.stop()
        server = null
        running = false
        try { wl?.release() } catch (e: Exception) {}
        super.onDestroy()
    }
}
