package com.hotspotproxy

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

/** شاشة تشبه مشغل موسيقى. اضغط مطولاً على الغلاف وأدخل الرمز لفتح اللوحة. */
class MainActivity : Activity() {

    private var tone: Tone? = null
    private lateinit var playBtn: TextView
    private lateinit var seek: SeekBar
    private val h = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            if (tone != null) seek.progress = (seek.progress + 1) % 100
            h.postDelayed(this, 1000)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String, size: Float, color: Int) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color); gravity = Gravity.CENTER
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(Color.parseColor("#121212"))
            setPadding(dp(24), dp(48), dp(24), dp(24))
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }

        val art = TextView(this).apply {
            text = "♪"; textSize = 90f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#7B2FF7"), Color.parseColor("#2F80ED"))
            ).apply { cornerRadius = dp(24).toFloat() }
            setOnLongClickListener { askPin(); true }
        }
        root.addView(art, LinearLayout.LayoutParams(dp(280), dp(280)).apply { bottomMargin = dp(32) })

        root.addView(label("Midnight Drive", 22f, Color.WHITE))
        root.addView(label("Lo-Fi Collective", 15f, Color.parseColor("#9E9E9E")))

        seek = SeekBar(this).apply { max = 100 }
        root.addView(seek, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(24); bottomMargin = dp(16) })

        val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
        val prev = label("⏮", 36f, Color.WHITE)
        playBtn = label("▶", 48f, Color.WHITE)
        val next = label("⏭", 36f, Color.WHITE)
        playBtn.setOnClickListener { togglePlay() }
        row.addView(prev, LinearLayout.LayoutParams(dp(80), dp(80)))
        row.addView(playBtn, LinearLayout.LayoutParams(dp(100), dp(100)))
        row.addView(next, LinearLayout.LayoutParams(dp(80), dp(80)))
        root.addView(row)

        setContentView(root)
    }

    override fun onResume() { super.onResume(); h.post(ticker) }
    override fun onStop() { super.onStop(); stopPlay(); h.removeCallbacks(ticker) }

    private fun togglePlay() { if (tone == null) startPlay() else stopPlay() }

    private fun startPlay() {
        tone = Tone()
        playBtn.text = "⏸"
    }

    private fun stopPlay() {
        tone?.stop()
        tone = null
        if (::playBtn.isInitialized) playBtn.text = "▶"
    }

    private fun askPin() {
        val e = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            hint = "الرمز"
        }
        AlertDialog.Builder(this)
            .setView(e)
            .setPositiveButton("موافق") { _, _ ->
                val pin = getSharedPreferences("cfg", MODE_PRIVATE).getString("pin", "1234")
                if (e.text.toString() == pin) startActivity(Intent(this, PanelActivity::class.java))
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    /** نغمة بسيطة (لحن Ode to Joy، ملك عام) تتكرر. */
    private class Tone {
        @Volatile private var running = true

        init {
            val t = Thread {
                val sr = 22050
                val minBuf = AudioTrack.getMinBufferSize(
                    sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
                )
                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sr)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
                    )
                    .setBufferSizeInBytes(minBuf * 2)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()
                track.play()
                val notes = doubleArrayOf(
                    329.63, 329.63, 349.23, 392.0, 392.0, 349.23, 329.63, 293.66,
                    261.63, 261.63, 293.66, 329.63, 329.63, 293.66, 293.66
                )
                val beats = doubleArrayOf(1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.5, 0.5, 2.0)
                var i = 0
                while (running) {
                    val idx = i % notes.size
                    val n = (sr * 0.4 * beats[idx]).toInt()
                    val buf = ShortArray(n)
                    for (k in 0 until n) {
                        val env = minOf(1.0, k / 800.0, (n - k) / 1500.0)
                        buf[k] = (Math.sin(2 * Math.PI * notes[idx] * k / sr) * 9000 * env).toInt().toShort()
                    }
                    track.write(buf, 0, n)
                    i++
                }
                try { track.stop() } catch (e: Exception) {}
                track.release()
            }
            t.isDaemon = true
            t.start()
        }

        fun stop() { running = false }
    }
}
