package com.hotspotproxy

import android.util.Base64
import java.io.BufferedInputStream
import java.io.DataInputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.URL
import java.util.concurrent.Executors

/** وكيل بسيط: SOCKS5 + HTTP/HTTPS على نفس المنفذ. */
class ProxyServer(private val port: Int, private val user: String, private val pass: String) {

    private var server: ServerSocket? = null
    private val pool = Executors.newCachedThreadPool()
    @Volatile private var stopped = false

    private val needAuth get() = user.isNotEmpty() || pass.isNotEmpty()

    fun start() {
        val s = ServerSocket()
        s.reuseAddress = true
        s.bind(InetSocketAddress(port)) // 0.0.0.0 = كل الشبكات، منها الهوت سبوت
        server = s
        val t = Thread {
            while (!stopped) {
                try {
                    val c = s.accept()
                    pool.execute { handle(c) }
                } catch (e: IOException) {
                    if (stopped) break
                } catch (e: Exception) {
                    if (stopped) break
                }
            }
        }
        t.isDaemon = true
        t.start()
    }

    fun stop() {
        stopped = true
        try { server?.close() } catch (e: Exception) {}
        pool.shutdownNow()
    }

    private fun handle(c: Socket) {
        try {
            c.soTimeout = 20000
            c.tcpNoDelay = true
            val inp = BufferedInputStream(c.getInputStream(), 16384)
            val out = c.getOutputStream()
            inp.mark(1)
            val first = inp.read()
            if (first < 0) return
            inp.reset()
            if (first == 5) socks5(c, inp, out) else http(c, inp, out)
        } catch (e: Exception) {
        } finally {
            try { c.close() } catch (e: Exception) {}
        }
    }

    // ---------------- SOCKS5 ----------------
    private fun socks5(c: Socket, inp: InputStream, out: OutputStream) {
        val d = DataInputStream(inp)
        d.readUnsignedByte() // version
        val n = d.readUnsignedByte()
        val methods = ByteArray(n)
        d.readFully(methods)
        val want = if (needAuth) 2 else 0
        if (methods.none { it.toInt() == want }) {
            out.write(byteArrayOf(5, -1)); out.flush(); return
        }
        out.write(byteArrayOf(5, want.toByte())); out.flush()
        if (needAuth) {
            d.readUnsignedByte()
            val u = ByteArray(d.readUnsignedByte()); d.readFully(u)
            val p = ByteArray(d.readUnsignedByte()); d.readFully(p)
            if (String(u) != user || String(p) != pass) {
                out.write(byteArrayOf(1, 1)); out.flush(); return
            }
            out.write(byteArrayOf(1, 0)); out.flush()
        }
        d.readUnsignedByte() // version
        val cmd = d.readUnsignedByte()
        d.readUnsignedByte() // reserved
        val atyp = d.readUnsignedByte()
        val host: String = when (atyp) {
            1 -> { val b = ByteArray(4); d.readFully(b); InetAddress.getByAddress(b).hostAddress ?: return }
            3 -> { val b = ByteArray(d.readUnsignedByte()); d.readFully(b); String(b) }
            4 -> { val b = ByteArray(16); d.readFully(b); InetAddress.getByAddress(b).hostAddress ?: return }
            else -> { socksReply(out, 8); return }
        }
        val dport = d.readUnsignedShort()
        if (cmd != 1) { socksReply(out, 7); return }
        val remote = try { connect(host, dport) } catch (e: Exception) { socksReply(out, 4); return }
        socksReply(out, 0)
        pipe(c, inp, remote)
    }

    private fun socksReply(out: OutputStream, code: Int) {
        out.write(byteArrayOf(5, code.toByte(), 0, 1, 0, 0, 0, 0, 0, 0))
        out.flush()
    }

    // ---------------- HTTP ----------------
    private fun http(c: Socket, inp: InputStream, out: OutputStream) {
        val reqLine = rl(inp) ?: return
        val headers = ArrayList<String>()
        while (true) {
            val l = rl(inp) ?: break
            if (l.isEmpty()) break
            headers.add(l)
        }
        val parts = reqLine.split(" ")
        if (parts.size < 3) return
        val method = parts[0]
        val target = parts[1]
        val version = parts[2]

        if (needAuth && !authOk(headers)) {
            out.write(("HTTP/1.1 407 Proxy Authentication Required\r\n" +
                "Proxy-Authenticate: Basic realm=\"proxy\"\r\n" +
                "Content-Length: 0\r\nConnection: close\r\n\r\n").toByteArray())
            out.flush()
            return
        }

        if (method.equals("CONNECT", true)) {
            val host = target.substringBeforeLast(":").removePrefix("[").removeSuffix("]")
            val dport = target.substringAfterLast(":").toIntOrNull() ?: 443
            val remote = try { connect(host, dport) } catch (e: Exception) { badGateway(out); return }
            out.write("HTTP/1.1 200 Connection Established\r\n\r\n".toByteArray())
            out.flush()
            pipe(c, inp, remote)
            return
        }

        val url = try { URL(target) } catch (e: Exception) { return }
        val host = url.host ?: return
        val dport = if (url.port > 0) url.port else 80
        val path = (if (url.path.isNullOrEmpty()) "/" else url.path) +
            (if (url.query != null) "?" + url.query else "")
        val remote = try { connect(host, dport) } catch (e: Exception) { badGateway(out); return }
        val sb = StringBuilder("$method $path $version\r\n")
        for (h in headers) {
            val k = h.substringBefore(":").trim().lowercase()
            if (k.startsWith("proxy-") || k == "connection") continue
            sb.append(h).append("\r\n")
        }
        sb.append("Connection: close\r\n\r\n")
        remote.getOutputStream().write(sb.toString().toByteArray())
        remote.getOutputStream().flush()
        pipe(c, inp, remote)
    }

    private fun authOk(headers: List<String>): Boolean {
        val h = headers.firstOrNull { it.startsWith("Proxy-Authorization:", true) } ?: return false
        return try {
            val tok = h.substringAfter(":").trim().substringAfter(" ").trim()
            String(Base64.decode(tok, Base64.DEFAULT)) == "$user:$pass"
        } catch (e: Exception) { false }
    }

    private fun badGateway(out: OutputStream) {
        out.write("HTTP/1.1 502 Bad Gateway\r\nContent-Length: 0\r\nConnection: close\r\n\r\n".toByteArray())
        out.flush()
    }

    private fun rl(i: InputStream): String? {
        val sb = StringBuilder()
        while (true) {
            val b = i.read()
            if (b < 0) return if (sb.isEmpty()) null else sb.toString()
            if (b == '\n'.code) break
            if (b != '\r'.code) sb.append(b.toChar())
            if (sb.length > 16384) throw IOException("line too long")
        }
        return sb.toString()
    }

    // ---------------- مشترك ----------------
    private fun connect(host: String, dport: Int): Socket {
        val s = Socket()
        try {
            s.tcpNoDelay = true
            s.connect(InetSocketAddress(host, dport), 15000)
            return s
        } catch (e: Exception) {
            try { s.close() } catch (e2: Exception) {}
            throw e
        }
    }

    private fun pipe(client: Socket, clientIn: InputStream, remote: Socket) {
        try {
            client.soTimeout = 0
            val t = Thread {
                copy(clientIn, remote.getOutputStream())
                try { remote.shutdownOutput() } catch (e: Exception) {}
            }
            t.isDaemon = true
            t.start()
            copy(remote.getInputStream(), client.getOutputStream())
            try { client.shutdownOutput() } catch (e: Exception) {}
            t.join(30000)
        } finally {
            try { remote.close() } catch (e: Exception) {}
        }
    }

    private fun copy(i: InputStream, o: OutputStream) {
        val buf = ByteArray(16384)
        try {
            while (true) {
                val n = i.read(buf)
                if (n < 0) break
                o.write(buf, 0, n)
                o.flush()
            }
        } catch (e: IOException) {
        }
    }
}
