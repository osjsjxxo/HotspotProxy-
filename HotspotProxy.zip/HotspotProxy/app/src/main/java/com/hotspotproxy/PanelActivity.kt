package com.hotspotproxy

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.net.Inet4Address
import java.net.NetworkInterface

class PanelActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var addr: TextView
    private lateinit var btn: Button
    private lateinit var portE: EditText
    private lateinit var userE: EditText
    private lateinit var passE: EditText
    private lateinit var pinE: EditText
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { refresh(); h.postDelayed(this, 1500) }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(t: String, size: Float = 16f) = TextView(this).apply {
        text = t
        textSize = size
        setPadding(0, dp(8), 0, dp(8))
    }

    private fun et(hintText: String, value: String, type: Int) = EditText(this).apply {
        hint = hintText
        setText(value)
        inputType = type
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = getSharedPreferences("cfg", MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        root.addView(tv("الوضع 1: وكيل الهوت سبوت", 22f))
        status = tv("", 18f); root.addView(status)
        addr = tv("", 16f); addr.setTextIsSelectable(true); root.addView(addr)

        portE = et("المنفذ", p.getInt("port", 8080).toString(), InputType.TYPE_CLASS_NUMBER)
        userE = et("اسم المستخدم (اختياري)", p.getString("user", "") ?: "", InputType.TYPE_CLASS_TEXT)
        passE = et("كلمة المرور (اختياري)", p.getString("pass", "") ?: "", InputType.TYPE_CLASS_TEXT)
        pinE = et("رمز الدخول لهذه الشاشة", p.getString("pin", "1234") ?: "1234", InputType.TYPE_CLASS_NUMBER)
        root.addView(portE); root.addView(userE); root.addView(passE)

        btn = Button(this).apply { setOnClickListener { toggle() } }
        root.addView(btn)
        root.addView(Button(this).apply {
            text = "فتح إعدادات الهوت سبوت"
            setOnClickListener { openTether() }
        })
        root.addView(tv("الخطوات:\n١) شغّل الـ VPN\n٢) شغّل الهوت سبوت\n٣) اضغط ابدأ\n" +
            "٤) بالجهاز الثاني: واي فاي ← بروكسي يدوي ← العنوان والمنفذ", 14f))

        root.addView(tv("الوضع 2: تمرير كل التطبيقات (Shizuku)", 22f))
        root.addView(tv("يشتغل عن طريق تطبيق Shizzi المنصّب عندك.", 14f))
        root.addView(Button(this).apply {
            text = "فتح Shizzi"
            setOnClickListener { openShizzi() }
        })
        root.addView(tv("غيّر رمز الدخول إذا تريد:", 14f))
        root.addView(pinE)

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick); save() }

    private fun save(): Int? {
        val port = portE.text.toString().toIntOrNull()
        val e = getSharedPreferences("cfg", MODE_PRIVATE).edit()
        if (port != null && port in 1024..65535) e.putInt("port", port)
        e.putString("user", userE.text.toString())
        e.putString("pass", passE.text.toString())
        val pin = pinE.text.toString()
        if (pin.isNotEmpty()) e.putString("pin", pin)
        e.apply()
        return port
    }

    private fun toggle() {
        val svc = Intent(this, ProxyService::class.java)
        if (ProxyService.running) {
            stopService(svc)
            ProxyService.running = false
            refresh()
            return
        }
        val port = save()
        if (port == null || port !in 1024..65535) {
            Toast.makeText(this, "المنفذ لازم يكون بين 1024 و 65535", Toast.LENGTH_LONG).show()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        startForegroundService(svc)
        h.postDelayed({ refresh() }, 600)
    }

    private fun refresh() {
        val on = ProxyService.running
        val err = ProxyService.lastError
        status.text = when {
            on -> "الحالة: شغال ✅"
            err != null -> "خطأ: $err"
            else -> "الحالة: متوقف"
        }
        btn.text = if (on) "إيقاف" else "ابدأ"
        val port = portE.text.toString()
        addr.text = if (on) {
            "اكتب بالجهاز الثاني:\n" +
                ips().joinToString("\n") { "${it.second}:$port   (${it.first})" } +
                "\n\nالعنوان اللي يبدأ بـ 192.168 غالباً هو الهوت سبوت"
        } else ""
    }

    private fun ips(): List<Pair<String, String>> = try {
        val list = ArrayList<Pair<String, String>>()
        val all = NetworkInterface.getNetworkInterfaces()
        while (all != null && all.hasMoreElements()) {
            val ni = all.nextElement()
            if (!ni.isUp || ni.isLoopback) continue
            val a = ni.inetAddresses
            while (a.hasMoreElements()) {
                val ad = a.nextElement()
                if (ad is Inet4Address && !ad.isLoopbackAddress) {
                    list.add(Pair(ni.name, ad.hostAddress ?: ""))
                }
            }
        }
        list
    } catch (e: Exception) { emptyList() }

    private fun openTether() {
        try {
            startActivity(Intent("android.settings.TETHER_SETTINGS"))
        } catch (e: Exception) {
            try { startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS)) } catch (e2: Exception) {}
        }
    }

    private fun openShizzi() {
        val i = packageManager.getLaunchIntentForPackage("dev.shizzi")
        if (i != null) startActivity(i)
        else Toast.makeText(this, "Shizzi غير منصّب", Toast.LENGTH_LONG).show()
    }
}
